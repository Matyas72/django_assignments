from django.shortcuts import render, redirect
from django.contrib import messages
import bcrypt
from .models import *


def log_reg(request):
    return render(request, "log_reg.html")


def register(request):
    if request.method == "POST":
        errors = User.objects.Basic_Validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect('/')
        else:
            password = request.POST['password']
            pw_hash = bcrypt.hashpw(
                password.encode(), bcrypt.gensalt()).decode()

            user = User.objects.create(
                first_name=request.POST['first_name'],
                last_name=request.POST['last_name'],
                email=request.POST['email'],
                password=pw_hash
            )
            request.session['user_id'] = user.id
            return redirect('/')
    return redirect('/')


def login(request):
    if request.method == "POST":
        user = User.objects.filter(email=request.POST['email'])
        if user:
            logged_user = user[0]
            if bcrypt.checkpw(request.POST['password'].encode(), logged_user.password.encode()):
                request.session['user_id'] = logged_user.id
                return redirect('/success')
        messages.error(request, "Email or password are wrong!")
    return redirect('/')


def main_page(request):
    if 'user_id' not in request.session:
        return redirect('/')
    context = {
        'current_user': User.objects.get(id=request.session['user_id'])
    }
    return render(request, "main_page.html", context)


def logout(request):
    request.session.flush()
    return redirect('/')
