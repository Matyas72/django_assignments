from django.urls import path
from . import views

urlpatterns = [

    path('', views.log_reg),
    path('register', views.register),
    path('login', views.login),
    path('success', views.main_page),
    path('logout', views.logout),
]
