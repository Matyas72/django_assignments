from django.db import models
import re


class UserManager(models.Manager):
    def Basic_Validator(self, postData):
        errors = {}
        if len(postData['first_name']) < 2:
            errors["first_name"] = "The first name should be at least 2 characters"
        if len(postData['last_name']) < 2:
            errors["last_name"] = "The last name should be at least 2 characters"
        if len(postData['password']) < 8:
            errors["password_short"] = "The password should be at least 8 characters"
        if postData['password'] != postData['password_conf']:
            errors["pw_match"] = "The passwords don't match"
        EMAIL_REGEX = re.compile(
            r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(postData['email']):
            errors['email'] = ("Invalid email address!")
        users_with_email = User.objects.filter(email=postData['email'])
        if len(users_with_email) >= 1:
            errors['email_duplicate'] = "Email taken already, use another email"

        return errors


class User(models.Model):
    first_name = models.CharField(max_length=70)
    last_name = models.CharField(max_length=70)
    email = models.TextField()
    password = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()
