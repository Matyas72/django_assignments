from django.shortcuts import render, redirect

from .models import *


def main_page(request):
    return render(request, "main_page.html")


def index(request):
    context = {
        "book_list": book.objects.all(),
    }
    return render(request, "index.html", context)


def add_book(request):
    book.objects.create(
        title=request.POST['title'],
        desc=request.POST['desc']
    )

    return redirect('/books')


def view_book(request, book_id):

    context = {
        "book": book.objects.get(id=book_id),
        "author_list": author.objects.all()
    }
    return render(request, "book.html", context)


def author_to_book(request, book_id):

    book_x = book.objects.get(id=book_id)
    author_x = author.objects.get(id=request.POST['author_id'])
    book_x.authorsbooks.add(author_x)
    return redirect(f'/view_book/{book_id}')


def authors(request):
    context = {
        'author_list': author.objects.all()

    }
    return render(request, 'authors.html', context)


def add_author(request):
    author.objects.create(
        first_name=request.POST['first_name'],
        last_name=request.POST['last_name'],
        notes=request.POST['notes']
    )
    return redirect('/authors')


def view_author(request, author_id):
    context = {
        "author": author.objects.get(id=author_id),
        "book_list": book.objects.all()
    }
    return render(request, "author.html", context)


def book_to_author(request, author_id):

    author_y = author.objects.get(id=author_id)
    book_y = book.objects.get(id=request.POST['book_id'])
    author_y.books.add(book_y)
    return redirect(f'/view_author/{author_id}')
