from django.shortcuts import render, redirect


def index(request):
    return render(request, "index.html")


def info_sub(request):
    request.session['name'] = request.POST['full_name']
    request.session['location'] = request.POST['location']
    request.session['prog_language'] = request.POST['prog_language']
    return redirect('/result')

def result(request):
    return render(request, "result.html")
