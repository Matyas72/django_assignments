from django.shortcuts import render, redirect


def index(request):
    return render(request, "index.html")


def result(request):
    if request.method == 'POST':
        context = {
            'name': request.POST['full_name'],
            'loc': request.POST['location'],
            'lang': request.POST['prog_language'],
            'comment': request.POST['comment'],
        }
        return render(request, 'result.html', context)
    return render(request, 'result.html')
