from django.shortcuts import render, redirect
from django.contrib import messages

from .models import *


def main(request):
    return redirect('/shows')


def shows(request):
    context = {
        "all_the_shows": show.objects.all()
    }
    return render(request, "shows.html", context)


def add_show(request):
    return render(request, "add_show.html")


def view_show(request, show_id):
    context = {
        "show": show.objects.get(id=show_id)
    }
    return render(request, "show.html", context)


def edit_show(request, show_id):
    context = {
        "show_a": show.objects.get(id=show_id)
    }
    return render(request, "edit_show.html", context)


def destroy_show(request, show_id):
    show_to_destroy = show.objects.get(id=show_id)
    show_to_destroy.delete()
    return redirect('/shows')


def create_show(request):
    errors = show.objects.basic_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/shows/new')
    else:

        show.objects.create(
            title=request.POST['title'],
            network=request.POST['network'],
            release_date=request.POST['release_date'],
            desc=request.POST['description'],
        )
        return redirect('/shows')


def update_show(request, show_id):
    errors = show.objects.basic_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f'/shows/{show_id}/edit')
    else:

        show_to_update = show.objects.get(id=show_id)
        show_to_update.title = request.POST['title']
        show_to_update.network = request.POST['network']
        show_to_update.release_date = request.POST['release_date']
        show_to_update.desc = request.POST['description']
        show_to_update.save()
        return redirect('/shows')
