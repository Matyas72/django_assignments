from django.db import models
import re


class UserManager(models.Manager):
    def Basic_Validator(self, postData):
        errors = {}
        if len(postData['first_name']) < 2:
            errors["first_name"] = "The first name should be at least 2 characters"
        if len(postData['last_name']) < 2:
            errors["last_name"] = "The last name should be at least 2 characters"
        if len(postData['password']) < 8:
            errors["password_short"] = "The password should be at least 8 characters"
        if postData['password'] != postData['password_conf']:
            errors["pw_match"] = "The passwords don't match"
        EMAIL_REGEX = re.compile(
            r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(postData['email']):
            errors['email'] = ("Invalid email address!")
        users_with_email = User.objects.filter(email=postData['email'])
        if len(users_with_email) >= 1:
            errors['email_duplicate'] = "Email taken already, use another email"

        return errors


class User(models.Model):
    first_name = models.CharField(max_length=70)
    last_name = models.CharField(max_length=70)
    email = models.TextField()
    password = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()


class BookManager(models.Manager):
    def book_validator(self, postData):
        errors = {}
        if len(postData['title']) < 1:
            errors["no_title"] = "Title is required"
        if len(postData['description']) < 5:
            errors["short_desc"] = "The description must be at least 5 characters long"
        book_with_title = Book.objects.filter(title=postData['title'])
        if len(book_with_title) >= 1:
            errors['book_duplicate'] = "This book is already uploaded"
        return errors


class Book(models.Model):
    title = models.CharField(max_length=255)
    desc = models.TextField()
    uploaded_by = models.ForeignKey(
        User, related_name="books_uploaded", on_delete=models.CASCADE)
    users_who_like = models.ManyToManyField(User, related_name="liked_books")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = BookManager()
