from django.shortcuts import render, redirect
from django.contrib import messages
import bcrypt
from .models import *


def log_reg(request):
    return render(request, "log_reg.html")


def register(request):
    if request.method == "POST":
        errors = User.objects.Basic_Validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect('/')
        else:
            password = request.POST['password']
            pw_hash = bcrypt.hashpw(
                password.encode(), bcrypt.gensalt()).decode()

            user = User.objects.create(
                first_name=request.POST['first_name'],
                last_name=request.POST['last_name'],
                email=request.POST['email'],
                password=pw_hash
            )
            request.session['user_id'] = user.id
            return redirect('/')
    return redirect('/')


def login(request):
    if request.method == "POST":
        user = User.objects.filter(email=request.POST['email'])
        if user:
            logged_user = user[0]
            if bcrypt.checkpw(request.POST['password'].encode(), logged_user.password.encode()):
                request.session['user_id'] = logged_user.id
                return redirect('/main_page')
        messages.error(request, "Email or password are wrong!")
    return redirect('/')


def main_page(request):
    if 'user_id' not in request.session:
        return redirect('/')
    context = {
        'current_user': User.objects.get(id=request.session['user_id']),
        'all_books': Book.objects.all()

    }
    return render(request, "main_page.html", context)


def logout(request):
    request.session.flush()
    return redirect('/')


def add_book(request):
    if 'user_id' not in request.session:
        return redirect('/')
    if request.method == "POST":
        errors = Book.objects.book_validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect('/main_page')
        else:
            user = User.objects.get(id=request.session['user_id'])
            book = Book.objects.create(
                title=request.POST['title'],
                desc=request.POST['description'],
                uploaded_by=User.objects.get(id=request.session['user_id']),

            )
            book.users_who_like.add(user)

            return redirect('/main_page')
    return redirect('/main_page')


def view_book(request, book_id):
    if 'user_id' not in request.session:
        return redirect('/')
    context = {
        'current_user': User.objects.get(id=request.session['user_id']),
        'current_book': Book.objects.get(id=book_id),
    }
    current_user = User.objects.get(id=request.session['user_id'])
    book_uploader = User.objects.get(books_uploaded=book_id)

    if book_uploader.id == current_user.id:
        return render(request, "single_book.html", context)
    else:
        return render(request, "single_book_view_only.html", context)


def edit_book(request, book_id):
    if 'user_id' not in request.session:
        return redirect('/')
    book_to_update = Book.objects.get(id=book_id)
    book_to_update.title = request.POST['title']
    book_to_update.description = request.POST['description']
    book_to_update.save()
    return redirect(f'/books/{book_id}')


def delete_book(request, book_id):
    if request.method == "POST":
        if 'user_id' not in request.session:
            return redirect('/')
        book_to_delete = Book.objects.get(id=book_id)
        book_to_delete.delete()
        return redirect('/main_page')
    return redirect('/main_page')


def add_fav(request, book_id):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    book = Book.objects.get(id=book_id)
    book.users_who_like.add(user)
    return redirect('/main_page')


def un_fav(request, book_id):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    book = Book.objects.get(id=book_id)
    book.users_who_like.remove(user)
    return redirect('/main_page')
