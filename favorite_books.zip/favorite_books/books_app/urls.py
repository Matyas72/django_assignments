from django.urls import path
from . import views

urlpatterns = [

    path('', views.log_reg),
    path('register', views.register),
    path('login', views.login),
    path('main_page', views.main_page),
    path('logout', views.logout),
    path('main_page/add_book', views.add_book),
    path('books/<int:book_id>', views.view_book),
    path('books/<int:book_id>/edit', views.edit_book),
    path('books/<int:book_id>/delete', views.delete_book),
    path('books/<int:book_id>/add_fav', views.add_fav),
    path('books/<int:book_id>/un_fav', views.un_fav),
]
